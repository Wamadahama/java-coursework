public interface Process {

    void processInput (String s);
}