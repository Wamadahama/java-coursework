/**
 * @author Haiping Xu
 * Created on Nov. 1, 2008
 */
public class ListException extends Exception {

    public ListException(String s) {
        System.out.println("ListException: " + s);
    }
}
