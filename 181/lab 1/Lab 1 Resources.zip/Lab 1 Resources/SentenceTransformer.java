/**
 * @author
 *
 */
public class SentenceTransformer {
	
	static String firstWord (String thePhrase) {
		/* take 'thePhrase' and return only the first word*/
	}

	static String lastWords (String thePhrase) {
		/* take 'thePhrase' and return the entire phrase except the first word */
	}

	static int countCharacter(String thePhrase,char letter){
		/* take 'thePhrase' and return the number of times 'letter' occurs in it 
		 * example:    SentenceTransformer.countCharacter("This is one boring lab", 'o') 
		 * would return 2
		 */

	}
	
	static String depunctuate (String thePhrase){
		/* take 'thePhrase' and remove '.' '!' and '?' characters
		 * from it and replace them with ' ' (spaces)
		 */

	}
}
