/**
 * @author 
 */
public class WordTransformer {

	
	static String makeCapital (String theWord){
		/* return 'theWord' with the first letter capitalized */
	
	}

	static String lowerCase (String theWord){
		/* return 'theWord' with the first letter in lowercase */
	
	}

	static String upperCaser (String theWord) {
		/* return 'theWord' in all uppercase */

	}

	static String lowerCaser (String thePhrase) {
		/* return 'theWord' in all lowerCase */

	}

	static String ezEncrypt (String theWord) {
		/* this method will take the every even/odd pair of letters and swaps them.
		 * In the case of an odd length word, the last letter will not move.
		 * Example theWord = "Super"
		 * returns "uSper"
		 */

	}
}
